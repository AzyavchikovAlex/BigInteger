#include "equation_solver.h"

equation_solver::QuadraticEquation equation_solver::
GenerateEquation(const big_num_arithmetic::BigInteger& a,
                 const big_num_arithmetic::BigInteger& x1,
                 const big_num_arithmetic::BigInteger& x2) {
  QuadraticEquation answer;
  answer.a = a;
  answer.b = (x1 + x2) * a;
  answer.b.Negate();
  answer.c = (a * x1) * x2;
  return answer;
}
bool equation_solver::Solve(const equation_solver::QuadraticEquation& equation,
                            big_num_arithmetic::BigInteger& x1,
                            big_num_arithmetic::BigInteger& x2) {
  big_num_arithmetic::BigInteger discriminant;
  discriminant = equation.b * equation.b - (4 * (equation.a * equation.c));
  if (discriminant.Sign() == -1) {
    return false;
  }
  discriminant = equation_solver::helpers::Sqrt(discriminant);
  x1 = ((discriminant - equation.b) / 2) / equation.a;
  discriminant.Negate();
  x2 = ((discriminant - equation.b) / 2) / equation.a;
  return true;
}
