#ifndef HELPERS_H_
#define HELPERS_H_
namespace equation_solver {
namespace helpers {
template<typename T>
T Sqrt(const T& value) {
  T zero(0);
  if (value == zero) {
    return zero;
  }
  T one(1), left_border(1), two(2), mid(0);
  T right_border = static_cast<T>((value / two));
  while (left_border < right_border) {
    mid = (left_border + right_border) / two;
    if (mid < value / mid) {
      left_border = mid + one;
    } else {
      right_border = mid;
    }
  }
  if (left_border > value / left_border) {
    left_border = left_border - one;
  }
  return left_border;
}
}  // namespace helpers
}  // namespace equation_solver
#endif  // HELPERS_H_
