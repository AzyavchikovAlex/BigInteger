//
// Created by Админ on 06.11.2021.
//
#include <gtest/gtest.h>
#include "big_integer.h"
#include "helpers.h"
#include "equation_solver.h"
TEST(IsItWorking, Sample0) {
  big_num_arithmetic::BigInteger value1, expected_value;
  value1.FromString("123", 10);
  expected_value.FromString("00123", 10);
  std::cout << "\n" << value1 << "\n" << expected_value << "\n";
  ASSERT_EQ(value1, expected_value);
  EXPECT_EQ(1, 1);
}

TEST(BigInteger, MakingNumber) {
  big_num_arithmetic::BigInteger value;
  big_num_arithmetic::BigInteger::internal_base = 8;
  std::string value_in_string = "10";
  value = big_num_arithmetic::BigInteger::FromString(value_in_string, 10);
  ASSERT_EQ(value.ToString(10), "10");

  for (int i = -500000; i <= 500000; ++i) {
    value_in_string = std::to_string(i);
    value = big_num_arithmetic::BigInteger::FromString(value_in_string, 10);
    ASSERT_EQ(value.ToString(10), value_in_string);
  }
}

TEST(BigInteger, Comparing) {
  big_num_arithmetic::BigInteger value1, value2;
  big_num_arithmetic::BigInteger::internal_base = 4;
  for (int i = -1000; i <= 1000; ++i) {
    for (int j = -1000; j <= 1000; ++j) {
      value1 = static_cast<big_num_arithmetic::BigInteger>(i);
      value2 = static_cast<big_num_arithmetic::BigInteger>(j);
      // std::cout<<i<<"\t"<<j<<"\n";
      ASSERT_EQ(value1 == value2, bool(i==j));
      ASSERT_EQ(value1 != value2, bool(i!=j));
      ASSERT_EQ(value1 < value2, bool(i<j));
      ASSERT_EQ(value1 > value2, bool(i>j));
      ASSERT_EQ(value1 <= value2, bool(i<=j));
      ASSERT_EQ(value1 >= value2, bool(i>=j));

      ASSERT_EQ(value1 == j, bool(i==j));
      ASSERT_EQ(j == value1, bool(i==j));

      ASSERT_EQ(value1 != j, bool(i!=j));
      ASSERT_EQ(j != value1, bool(i!=j));

      ASSERT_EQ(value1 < j, bool(i<j));
      ASSERT_EQ(j > value1, bool(i<j));

      ASSERT_EQ(value1 > j, bool(i>j));
      ASSERT_EQ(j < value1, bool(i>j));

      ASSERT_EQ(value1 <= j, bool(i<=j));
      ASSERT_EQ(j >= value1, bool(i<=j));

      ASSERT_EQ(value1 >= j, bool(i>=j));
      ASSERT_EQ(j <= value1, bool(i>=j));
    }
  }
}

TEST (BigInteger, PlusAndMinus_Sample) {
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.FromString("123123123123124", 10);
    value2.FromString("123123123123123", 10);
    expected_value.FromString("246246246246247", 10);
    EXPECT_EQ(value1 + value2, expected_value);
    expected_value.FromString("1", 10);
    EXPECT_EQ(value1 - value2, expected_value);
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.FromString("999999999999999", 10);
    value2.FromString("111111111111111", 10);
    expected_value.FromString("1111111111111110", 10);
    EXPECT_EQ(value1 + value2, expected_value);
    expected_value.FromString("888888888888888", 10);
    EXPECT_EQ(value1 - value2, expected_value);
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.FromString("0000987654321", 10);
    value2.FromString("0000123456789", 10);
    expected_value.FromString("0001111111110", 10);
    EXPECT_EQ(value1 + value2, expected_value);
    expected_value.FromString("0000864197532", 10);
    EXPECT_EQ(value1 - value2, expected_value);
  }
}

TEST (BigInteger, PlusAndMinus) {
  big_num_arithmetic::BigInteger value1, value2, expected_value;
  std::string value_in_string;
  const int kBorder = 1000;
  for (int i = -kBorder; i <= kBorder; ++i) {
    for (int j = -kBorder; j <= kBorder; ++j) {
      value_in_string = std::to_string(i);
      value1.FromString(value_in_string, 10);
      value_in_string = std::to_string(j);
      value2.FromString(value_in_string, 10);
      value_in_string = std::to_string(i + j);
      expected_value.FromString(value_in_string, 10);
      ASSERT_EQ(value1 + value2, expected_value);
      value_in_string = std::to_string(i - j);
      expected_value.FromString(value_in_string, 10);
      ASSERT_EQ(value1 - value2, expected_value);
    }
  }
}

TEST (BigInteger, PlusAndMinus_HugeTest) {
  big_num_arithmetic::BigInteger value1, value2, expected_value;
  value1.internal_base = 5;
  std::string value_in_string;
  const int kBorder = 1000000;
  for (int i = -kBorder; i <= kBorder; ++i) {
    for (int j = -100; j <= 100; ++j) {
      value_in_string = std::to_string(i);
      value1.FromString(value_in_string, 10);
      value_in_string = std::to_string(j);
      value2.FromString(value_in_string, 10);
      value_in_string = std::to_string(i + j);
      expected_value.FromString(value_in_string, 10);
      ASSERT_EQ(value1 + value2, expected_value);
      value_in_string = std::to_string(i - j);
      expected_value.FromString(value_in_string, 10);
      ASSERT_EQ(value1 - value2, expected_value);
    }
  }
}

TEST (BigInteger, ToAnotherBase) {
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 10;
    value2.internal_base = 15;
    expected_value.internal_base = 25;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 10;
    value2.internal_base = 11;
    expected_value.internal_base = 9;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 25;
    value2.internal_base = 3;
    expected_value.internal_base = 25;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 3;
    value2.internal_base = 3;
    expected_value.internal_base = 25;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 50;
    value2.internal_base = 25;
    expected_value.internal_base = 4;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.internal_base = 150;
    value2.internal_base = 11;
    expected_value.internal_base = 150;
    std::string value_in_string;
    const int kBorder = 460;
    for (int i = -kBorder; i <= kBorder; ++i) {
      for (int j = -kBorder; j <= kBorder; ++j) {
        value_in_string = std::to_string(i);
        value1.FromString(value_in_string, 10);
        value_in_string = std::to_string(j);
        value2.FromString(value_in_string, 10);
        value_in_string = std::to_string(i + j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 + value2, expected_value);
        value_in_string = std::to_string(i - j);
        expected_value.FromString(value_in_string, 10);
        ASSERT_EQ(value1 - value2, expected_value);
      }
    }
  }
}

TEST (BigInteger, Multiply_Sample) {
  big_num_arithmetic::BigInteger::internal_base = 4;
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1 = big_num_arithmetic::BigInteger::FromString("1024", 10);
    value2 = big_num_arithmetic::BigInteger::FromString("4", 10);
    expected_value = big_num_arithmetic::BigInteger::FromString("4096", 10);
    ASSERT_EQ(value1 * value2, expected_value);
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.FromString("100", 10);
    value2.FromString("12", 10);
    expected_value.FromString("1200", 10);
    value1 * value2;
    std::cout << "END_OF_WATCHING\n\n";
    ASSERT_EQ(value1 * value2, expected_value);
  }
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    value1.FromString("5", 10);
    value2.FromString("7", 10);
    expected_value.FromString("35", 10);
    ASSERT_EQ(value1 * value2, expected_value);
  }
}

TEST (BigInteger, Multiply_1) {
  big_num_arithmetic::BigInteger::internal_base = 6;
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    for (int i = -1000; i <= 1000; ++i) {
      for (int j = -1000; j <= 1000; ++j) {
        value1 = static_cast<big_num_arithmetic::BigInteger>(i);
        value2 = static_cast<big_num_arithmetic::BigInteger>(j);
        expected_value = static_cast<big_num_arithmetic::BigInteger>(i * j);
        ASSERT_EQ(value1 * value2, expected_value);
      }
    }
  }
}

TEST(BigInteger, Multiply_2) {
  big_num_arithmetic::BigInteger::internal_base = 4;
  {
    big_num_arithmetic::BigInteger value1, value2, expected_value;
    for (int i = -100000; i <= 100000; ++i) {
      for (int j = -100; j <= 100; ++j) {
        value1 = static_cast<big_num_arithmetic::BigInteger>(i);
        value2 = static_cast<big_num_arithmetic::BigInteger>(j);
        expected_value = static_cast<big_num_arithmetic::BigInteger>(i * j);
        ASSERT_EQ(value1 * value2, expected_value);
      }
    }
  }
}

// -100 and -10,
// -100 -25
// -99 -100
TEST (BigInteger, Divide_Sample) {
  big_num_arithmetic::BigInteger::internal_base = 4;
  big_num_arithmetic::BigInteger value1, value2, value3, result;
  value1 = big_num_arithmetic::BigInteger::FromString("-99", 10);
  value2 = big_num_arithmetic::BigInteger::FromString("-100", 10);
  value3 = big_num_arithmetic::BigInteger::FromString("0", 10);
  result = value1 / value2;
  ASSERT_EQ(result, value3);
  std::cout << "\n" << result << "\n";
}

TEST (BigInteger, Divide_1) {
  big_num_arithmetic::BigInteger::internal_base = 4;
  big_num_arithmetic::BigInteger value1, value2, value3;
  for (int i = -100; i <= 100; ++i) {
    for (int j = -100; j <= 100; ++j) {
      if (j == 0) {
        continue;
      }
      value1 = static_cast<big_num_arithmetic::BigInteger>(i);
      value2 = static_cast<big_num_arithmetic::BigInteger>(j);
      value3 = static_cast<big_num_arithmetic::BigInteger>(i / j);
      if (value1 / value2 != value3) {
        std::cout << value1 << "\t" << value2 << "\n";
      }
      ASSERT_EQ(value1 / value2, value3);
    }
  }
}

TEST(BigInteger, Divide_2) {
  big_num_arithmetic::BigInteger::internal_base = 4;
  big_num_arithmetic::BigInteger value1, value2, value3;
  for (int i = -100000; i <= -100000; ++i) {
    value1 = static_cast<big_num_arithmetic::BigInteger>(i);
    for (int j = -1000; j <= -1000; ++j) {
      if (j == 0) {
        break;
      }
      value2 = static_cast<big_num_arithmetic::BigInteger>(j);
      value3 = static_cast<big_num_arithmetic::BigInteger>(i / j);
      ASSERT_EQ(value1 / value2, value3);
    }
  }
}

TEST (BigInteger, Output) {
  const int kBorder = 1000000;
  {
    std::string answer, expected_answer;
    std::ostringstream file_output;
    file_output.setf(std::ios::showbase);
    file_output.setf(std::ios::dec);
    for (int i = -kBorder; i <= kBorder; ++i) {
      file_output << big_num_arithmetic::BigInteger(i) << "\n";
      expected_answer += std::to_string(i);
      expected_answer += "\n";
    }
    answer = file_output.str();
    ASSERT_EQ(answer, expected_answer);
  }
  {
    std::string answer, expected_answer;
    std::ostringstream file_output, expected_file_output;
    file_output.setf(std::ios::showbase);
    file_output.setf(std::ios::hex);
    expected_file_output.setf(std::ios::showbase);
    expected_file_output.setf(std::ios::hex);
    for (int i = -kBorder; i <= kBorder; ++i) {
      file_output << big_num_arithmetic::BigInteger(i) << "\n";
      expected_file_output << i << "\n";
    }
    answer = file_output.str();
    expected_answer = expected_file_output.str();
    ASSERT_EQ(answer, expected_answer);
  }
  {
    std::string answer, expected_answer;
    std::ostringstream file_output, expected_file_output;
    file_output.setf(std::ios::showbase);
    file_output.setf(std::ios::oct);
    expected_file_output.setf(std::ios::showbase);
    expected_file_output.setf(std::ios::oct);
    for (int i = -kBorder; i <= kBorder; ++i) {
      file_output << big_num_arithmetic::BigInteger(i) << "\n";
      expected_file_output << i << "\n";
    }
    answer = file_output.str();
    expected_answer = expected_file_output.str();
    ASSERT_EQ(answer, expected_answer);
  }
}

TEST (BigInteger, Input) {
  // const int kBorder=1000000;
  // {
  //   big_num_arithmetic::BigInteger value,expected_value;
  //   std::ostringstream file_output;
  //   std::istringstream file_input;
  //   file_output.setf(std::ios::showbase);
  //   file_output.setf(std::ios::dec);
  //   file_input.setf(std::ios::showbase);
  //   file_input.setf(std::ios::dec);
  //   for (int i = -kBorder; i <= kBorder; ++i) {
  //     file_output << big_num_arithmetic::BigInteger(i) << "\n";
  //   }
  //   file_input.str()=file_input.str();
  //   for(int i=-kBorder;i<=kBorder;++i){
  //     file_input>>value;
  //     expected_value= static_cast<big_num_arithmetic::BigInteger>(i);
  //     ASSERT_EQ(value,expected_value);
  //   }
  // }
}

TEST (Helpers, Sqrt_int) {
  {
    int expected_value, result;
    for (int i = 0; i <= 10000000; ++i) {
      expected_value = sqrt(i);
      result = equation_solver::helpers::Sqrt<int>(i);
      ASSERT_EQ(result, expected_value);
    }
  }
}

TEST (Helpers, Sqrt_BigInteger) {
  big_num_arithmetic::BigInteger value1, value2, value3;
  big_num_arithmetic::BigInteger::internal_base = 4;
  for (int i = 0; i < 100000; ++i) {
    value1 =
        static_cast<big_num_arithmetic::BigInteger>(static_cast<int>(sqrt(i)));
    value2 = static_cast<big_num_arithmetic::BigInteger>(i);
    value3 =
        equation_solver::helpers::Sqrt<big_num_arithmetic::BigInteger>(value2);
    ASSERT_EQ(value1, value3);
  }
}

TEST (Helpers, Solve) {
  big_num_arithmetic::BigInteger value1, value2, value3, value4, a(1);
  equation_solver::QuadraticEquation container;
  big_num_arithmetic::BigInteger::internal_base = 4;
  for (int i = -1000; i <= 1000; ++i) {
    value1 = static_cast<big_num_arithmetic::BigInteger>(i);
    for (int j = -1000; j <= 1000; ++j) {
      value2 = static_cast<big_num_arithmetic::BigInteger>(j);
      container = equation_solver::GenerateEquation(a, value1, value2);
      equation_solver::Solve(container, value3, value4);
      bool result = (value1 == value3 && value2 == value4)
          || (value1 == value4 && value2 == value3);
      if (!result) {
        std::cout << '\n' << value1 << "\t" << value2;
      }
      EXPECT_TRUE(result);
    }
  }
}

TEST (Helpers, Solve_BadTest1) {
  big_num_arithmetic::BigInteger value1, value2, value3, value4, a(1);
  equation_solver::QuadraticEquation container;
  big_num_arithmetic::BigInteger::internal_base = 4;
  value1 = static_cast<big_num_arithmetic::BigInteger>(1);
  value2 = static_cast<big_num_arithmetic::BigInteger>(2);
  container = equation_solver::GenerateEquation(a, value1, value2);
  equation_solver::Solve(container, value3, value4);
  bool result = (value1 == value3 && value2 == value4)
      || (value1 == value4 && value2 == value3);
  EXPECT_TRUE(result);
}

TEST (BigInteger, Unary) {
  big_num_arithmetic::BigInteger value1, value2, value3, value4, value5;
  big_num_arithmetic::BigInteger::internal_base = 3;
  for (int i = 0; i <= 10000; ++i) {
    value5 = static_cast<big_num_arithmetic::BigInteger>(i);
    ASSERT_EQ(value1, value5);
    ASSERT_EQ(value2, value5);
    value5 = static_cast<big_num_arithmetic::BigInteger>(-i);
    ASSERT_EQ(value3, value5);
    ASSERT_EQ(value4, value5);
    ++value1;
    --value3;
    value2 = value2++;
    value4 = value4--;
  }

}
// -------------------------------------------------------------------



#include "big_integer.h"
#include "gtest/gtest.h"
#include <iostream>
#include <chrono>
#include <random>

// std::mt19937_64 rnd(std::chrono::system_clock().now().time_since_epoch().count());
// std::mt19937_64 rnd(416);
std::mt19937_64 rnd(42);
std::mt19937 small_rnd(42);

using big_num_arithmetic::BigInteger;

/// add with -30
/// add with -9610 12
TEST(ToSring, BasTest1) {
  BigInteger value(static_cast<int64_t>(-9610));
  std::string in_string = value.ToString(16);
  std::cout << in_string << "\n";
  value.FromString(in_string, 16);
  std::cout << value.FromString(in_string, 16) << "\t" << value << "\n";
  ASSERT_TRUE((value.FromString(in_string, 16) == value));
}

TEST(Mudule, Sample) {
  int64_t a = -4516583221451431210;
  int32_t b = 6;
  int32_t expected = ((a % b) + b) % b; //2
  BigInteger value(a);
  ASSERT_EQ(value % b, expected);
}

TEST(Modular, Generator) {
  uint32_t b = 6;
  for (int it = 0; it < 100000; it++) {
    int64_t a = rnd();

    std::cout << a << " " << b << '\n';

    ASSERT_TRUE((BigInteger(static_cast<int64_t>(((a % b) + b) % b)) ==
        BigInteger(static_cast<int64_t>(BigInteger(a) % b))));
  }
}

TEST(ToString, Generator) {
  auto start = std::chrono::high_resolution_clock::now();
  freopen("output.txt", "w", stdout);
  int base = 8;
  BigInteger val;
  for (int it = 0; it < 1000; it++) {
    if (it % 100 == 0) {
      std::cerr << "\n\t" << it;
    }

    std::string long_input;
    int len = (small_rnd() % 1000) + 10;
    // int len = (small_rnd() % 10) + 10;

    std::cerr << len << '\n';

    for (int i = 0; i < len; i++) {
      long_input += "*";
      if (i == 0) {
        long_input[long_input.size() - 1] =
            static_cast<char>(((small_rnd() % (base - 1)) + 1) + '0');
      } else {
        long_input[long_input.size() - 1] =
            static_cast<char>((small_rnd() % base) + '0');
      }
    }

    BigInteger big_a(BigInteger::FromString(long_input, base));
    std::string cand = big_a.ToString(base);

    std::cout << long_input << '\n';
    std::cout << cand << '\n';

    ASSERT_TRUE(long_input == cand);
    if (long_input != cand) {
      std::cerr << "\n\nMISTAKE\n";
      break;
    }
  }
  auto finish = std::chrono::high_resolution_clock::now();
  std::cerr << "finish "
            << std::chrono::duration<double>(finish - start).count()
            << " seconds.\n";
}

TEST(Division, BadTest1) {
  int64_t a = -2233884934074879819;
  int64_t b = 32;

  BigInteger fi = BigInteger(a / static_cast<int64_t>(32));
  BigInteger se = BigInteger(a) / BigInteger(b);

  ASSERT_TRUE((BigInteger(a / static_cast<int64_t>(32)) ==
      BigInteger(a) / BigInteger(b)));
}
// TEST(Modular, BadTest2) {
//   int64_t a = -2233884934074879819;
//   uint32_t b = 32;
//
//   BigInteger fi = BigInteger(static_cast<int64_t>(((a % b) + b) % b));
//   BigInteger se = BigInteger(static_cast<int64_t>(BigInteger(a) % b));
//
//   ASSERT_TRUE((BigInteger(static_cast<int64_t>(((a % b) + b) % b)) ==
//                BigInteger(static_cast<int64_t>(BigInteger(a) % b))));
// }