#include "big_integer.h"

int big_num_arithmetic::BigInteger::internal_base = 150;
big_num_arithmetic::BigInteger::BigInteger() {
  numbers_.resize(0);
  sign_ = 0;
  base_ = internal_base;
}
big_num_arithmetic::BigInteger::BigInteger(int64_t value) {
  base_ = internal_base;
  if (value == 0) {
    numbers_.resize(0);
    sign_ = 0;
  } else {
    numbers_.resize(1);
    if (value > 0) {
      sign_ = 1;
      numbers_[0] = value;
    } else {
      sign_ = -1;
      numbers_[0] = -value;
    }
    this->FixOverflow();
  }
}
big_num_arithmetic::BigInteger::
operator int64_t() const {
  int64_t answer = 0;
  for (int i = Size() - 1; i >= 0; --i) {
    answer *= base_;
    answer += numbers_[i];
  }
  answer *= sign_;
  return answer;
}
int big_num_arithmetic::BigInteger::Sign() const {
  return sign_;
}
int big_num_arithmetic::BigInteger::Size() const {
  return numbers_.size();
}
void big_num_arithmetic::BigInteger::Negate() {
  sign_ *= -1;
}
void big_num_arithmetic::BigInteger::Abs() {
  sign_ = abs(sign_);
}
void big_num_arithmetic::BigInteger::Clear() {
  sign_ = 1;
  numbers_.resize(0);
  base_ = internal_base;
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
FromString(const std::string& number,
           int base) {
  BigInteger answer;
  int start_of_scanning = 0;
  answer.numbers_.resize(0);
  answer.base_ = base;
  if (number.empty()) {
    answer.sign_ = 0;
    answer.base_ = internal_base;
    return answer;
  }
  answer.numbers_.reserve(number.size());
  if (number[0] == '-') {
    ++start_of_scanning;
    answer.sign_ = -1;
  } else {
    answer.sign_ = 1;
  }
  while (start_of_scanning < number.size()
      && number[start_of_scanning] == '0') {
    ++start_of_scanning;
  }
  if (start_of_scanning >= number.size()) {
    answer.sign_ = 0;
    answer.base_ = internal_base;
    return answer;
  }
  for (int i = number.size() - 1; i >= start_of_scanning; --i) {
    if (number[i] > '9') {
      answer.numbers_.push_back(10 + static_cast<int>(number[i] - 'a'));
    } else {
      answer.numbers_.push_back(static_cast<int>(number[i] - '0'));
    }
  }
  return answer.ToAnotherBase(internal_base);
}
std::string big_num_arithmetic::BigInteger::ToString(int base) const {
  if (Sign() == 0) {
    return "0";
  }
  if (base_ == base) {
    std::string answer = "";
    if (Sign() == -1) {
      answer += "-";
    }
    for (int i = numbers_.size() - 1; i >= 0; --i) {
      answer += "*";
      if (numbers_[i] < 10) {
        answer[answer.size() - 1] = static_cast<char>('0' + numbers_[i]);
      } else {
        answer[answer.size() - 1] = static_cast<char>('a' + (numbers_[i] - 10));
      }
    }
    return answer;
  } else {
    return this->ToAnotherBase(base).ToString(base);
  }
}

bool big_num_arithmetic::BigInteger::
operator==(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != value.base_) {
    return (this->ToAnotherBase(BigInteger::internal_base)
        == value.ToAnotherBase(BigInteger::internal_base));
  }
  if (sign_ != value.sign_) {
    return false;
  }
  if (numbers_.size() != value.numbers_.size()) {
    return false;
  }
  for (int i = numbers_.size() - 1; i >= 0; --i) {
    if (numbers_[i] != value.numbers_[i]) {
      return false;
    }
  }
  return true;
}
bool big_num_arithmetic::BigInteger::
operator!=(const big_num_arithmetic::BigInteger& value) const {
  return (!(*this == value));
}
bool big_num_arithmetic::BigInteger::
operator>(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != value.base_) {
    return (this->ToAnotherBase(BigInteger::internal_base)
        > value.ToAnotherBase(BigInteger::internal_base));
  }
  if (sign_ != value.sign_) {
    return (sign_ > value.sign_);
  }
  if (numbers_.size() != value.numbers_.size()) {
    return ((numbers_.size() * sign_) > (value.numbers_.size() * value.sign_));
  }
  for (int i = numbers_.size() - 1; i >= 0; --i) {
    if (numbers_[i] != value.numbers_[i]) {
      return ((numbers_[i] * sign_) > (value.numbers_[i] * value.sign_));
    }
  }
  return false;
}
bool big_num_arithmetic::BigInteger::
operator<(const big_num_arithmetic::BigInteger& value) const {
  return (value > *this);
}
bool big_num_arithmetic::BigInteger::
operator>=(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != value.base_) {
    return (this->ToAnotherBase(BigInteger::internal_base)
        >= value.ToAnotherBase(BigInteger::internal_base));
  }
  if (sign_ != value.sign_) {
    return (sign_ > value.sign_);
  }
  if (numbers_.size() != value.numbers_.size()) {
    return ((numbers_.size() * sign_) > (value.numbers_.size() * value.sign_));
  }
  for (int i = numbers_.size() - 1; i >= 0; --i) {
    if (numbers_[i] != value.numbers_[i]) {
      return ((numbers_[i] * sign_) > (value.numbers_[i] * value.sign_));
    }
  }
  return true;
}
bool big_num_arithmetic::BigInteger::
operator<=(const big_num_arithmetic::BigInteger& value) const {
  return (value >= *this);
}
bool big_num_arithmetic::
operator==(const BigInteger& first_value,
           int64_t second_value) {
  return (first_value == static_cast
      <BigInteger>(second_value));
}
bool big_num_arithmetic::
operator==(int64_t first_value,
           const big_num_arithmetic::BigInteger& second_value) {
  return (second_value == first_value);
}
bool big_num_arithmetic::
operator!=(const BigInteger& first_value,
           int64_t second_value) {
  return (first_value != static_cast<BigInteger>(second_value));
}
bool big_num_arithmetic::
operator!=(int64_t first_value,
           const big_num_arithmetic::BigInteger& second_value) {
  return (second_value != first_value);
}
bool big_num_arithmetic::
operator>(const BigInteger& first_value,
          int64_t second_value) {
  return (first_value > static_cast<BigInteger>(second_value));
}
bool big_num_arithmetic::
operator>(int64_t first_value,
          const big_num_arithmetic::BigInteger& second_value) {
  return (second_value < first_value);
}
bool big_num_arithmetic::
operator<(const BigInteger& first_value,
          int64_t second_value) {
  return (first_value < static_cast<BigInteger>(second_value));
}
bool big_num_arithmetic::
operator<(int64_t first_value,
          const big_num_arithmetic::BigInteger& second_value) {
  return (second_value > first_value);
}
bool big_num_arithmetic::
operator>=(const BigInteger& first_value,
           int64_t second_value) {
  return (first_value >= static_cast<BigInteger>(second_value));
}
bool big_num_arithmetic::
operator>=(int64_t first_value,
           const big_num_arithmetic::BigInteger& second_value) {
  return (second_value <= first_value);
}
bool big_num_arithmetic::
operator<=(const BigInteger& first_value,
           int64_t second_value) {
  return (first_value <= static_cast<BigInteger>(second_value));
}
bool big_num_arithmetic::
operator<=(int64_t first_value,
           const big_num_arithmetic::BigInteger& second_value) {
  return (second_value >= first_value);
}

big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator+(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != value.base_) {
    return (this->ToAnotherBase(BigInteger::internal_base))
        + value.ToAnotherBase(BigInteger::internal_base);
  }
  if (sign_ == 0) {
    return value;
  }
  if (value.sign_ == 0) {
    return *this;
  }
  BigInteger answer;
  if (sign_ != value.sign_) {
    if (sign_ == -1) {
      answer = *this;
      answer.Negate();
      answer = (value - answer);
    } else {
      answer = value;
      answer.Negate();
      answer = ((*this) - answer);
    }
    return answer;
  }
  answer.sign_ = this->sign_;
  answer.base_ = this->base_;
  answer.numbers_.resize(std::max(this->Size(), value.Size()));
  for (int i = 0; i < answer.Size(); ++i) {
    answer.numbers_[i] = 0;
    if (i < this->Size()) {
      answer.numbers_[i] += this->numbers_[i];
    }
    if (i < value.Size()) {
      answer.numbers_[i] += value.numbers_[i];
    }
  }
  answer.FixOverflow();
  return answer;
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator+(const big_num_arithmetic::BigInteger& first_value,
          int64_t second_value) {
  return first_value + static_cast<BigInteger>(second_value);
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator+(int64_t first_value,
          const big_num_arithmetic::BigInteger& second_value) {
  return second_value + static_cast<BigInteger>(first_value);
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator-(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != value.base_) {
    return (this->ToAnotherBase(BigInteger::internal_base)
        - value.ToAnotherBase(BigInteger::internal_base));
  }
  if (sign_ == 0) {
    BigInteger answer = value;
    answer.Negate();
    return answer;
  }
  if (value.sign_ == 0) {
    return *this;
  }
  BigInteger answer;
  if (sign_ != value.sign_) {
    //  (+) - (-) = (+) + (+)
    //  (-) - (+) = (-) + (-)
    answer = value;
    answer.Negate();
    answer = (*this) + answer;
    return answer;
  }
  if (((*this) > value && sign_ == 1) || ((*this) < value && sign_ == -1)) {
    answer = *this;
    for (int i = 0; i < value.Size(); ++i) {
      answer.numbers_.at(i) -= value.numbers_[i];
    }
  } else {
    answer = value;
    answer.Negate();
    for (int i = 0; i < this->Size(); ++i) {
      answer.numbers_.at(i) -= this->numbers_[i];
    }
  }
  for (int i = 0; i < answer.Size(); ++i) {
    if (answer.numbers_[i] < 0) {
      answer.numbers_[i] += answer.base_;
      --answer.numbers_.at(i + 1);
    }
  }
  int new_size_of_answer = answer.Size();
  for (int i = answer.Size() - 1; i >= 0; --i) {
    if (answer.numbers_[i] == 0) {
      --new_size_of_answer;
    } else {
      break;
    }
  }
  answer.numbers_.resize(new_size_of_answer);
  if (new_size_of_answer == 0) {
    answer.sign_ = 0;
  }
  return answer;
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator-(const big_num_arithmetic::BigInteger& first_value,
          int64_t second_value) {
  return first_value - static_cast<BigInteger>(second_value);
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator-(int64_t first_value,
          const big_num_arithmetic::BigInteger& second_value) {
  return static_cast<BigInteger>(first_value) - second_value;
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator*(const big_num_arithmetic::BigInteger& value) const {
  if (base_ != BigInteger::internal_base) {
    return (this->ToAnotherBase(BigInteger::internal_base)
        * value);
  }
  if (value.base_ != BigInteger::internal_base) {
    return (*this
        * value.ToAnotherBase(BigInteger::internal_base));
  }
  BigInteger answer = this->Karatsuba(value);
  if (sign_ * value.sign_ == -1) {
    answer.Negate();
  }
  return answer;
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator*(const big_num_arithmetic::BigInteger& first_value,
          int64_t second_value) {
  return first_value * static_cast<BigInteger>(second_value);
}
big_num_arithmetic::BigInteger big_num_arithmetic::
operator*(int64_t first_value,
          const big_num_arithmetic::BigInteger& second_value) {
  return second_value * static_cast<BigInteger>(first_value);
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator/(const big_num_arithmetic::BigInteger& value) const {
  if (this->base_ != value.base_) {
    return this->ToAnotherBase(internal_base)
        / value.ToAnotherBase(internal_base);
  }
  int sign_of_answer = this->sign_ * value.sign_;
  BigInteger module_of_value = value;
  module_of_value.Abs();
  BigInteger reminder(0), answer(0);
  int64_t left_border, right_border, mid;
  for (int i = this->Size() - 1; i >= 0; --i) {
    reminder <<= 1;
    answer <<= 1;
    reminder += this->numbers_[i];
    if (reminder < module_of_value) {
      continue;
    }
    left_border = 1;
    right_border = this->base_ - 1;
    while (left_border < right_border) {
      mid = (left_border + right_border) >> 1;
      if ((module_of_value * mid) < reminder) {
        left_border = mid + 1;
      } else {
        right_border = mid;
      }
    }
    if (left_border * module_of_value > reminder) {
      --left_border;
    }
    reminder = reminder - (left_border * module_of_value);
    answer += left_border;
  }
  if (answer.Size() == 0) {
    answer.sign_ = 0;
  } else {
    answer.sign_ = sign_of_answer;
  }
  return answer;
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator/(int64_t value) const {
  if (BigInteger::BigInteger::SizeInBits(base_)
      + BigInteger::SizeInBits(value) >= 62) {
    return *this / static_cast<BigInteger>(value);
  }
  BigInteger answer = *this;
  if (value < 0) {
    answer.Negate();
    value = std::abs(value);
  }
  for (int i = Size() - 1; i >= 0; --i) {
    if (i != 0) {
      answer.numbers_[i - 1] += (answer.numbers_[i] % value) * answer.base_;
    }
    answer.numbers_[i] /= value;
  }
  answer.FixOverflow();
  return answer;
}
uint32_t big_num_arithmetic::BigInteger::operator%(uint32_t value) const {
  BigInteger answer = *this - (*this / value) * value;
  if (answer.Sign() == -1) {
    answer += value;
  }
  return int64_t(answer);
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator<<(int value) const {
  BigInteger answer = *this;
  answer <<= value;
  return answer;
}
void big_num_arithmetic::BigInteger::operator<<=(int value) {
  assert(value >= 0);
  if (sign_ == 0) {
    return;
  }
  int last_value = numbers_.size() - 1;
  numbers_.resize(numbers_.size() + value);
  for (int i = last_value; i >= 0; --i) {
    numbers_[i + value] = numbers_[i];
  }
  for (int i = 0; i < value; ++i) {
    numbers_[i] = 0;
  }
}
void big_num_arithmetic::BigInteger::
operator+=(const big_num_arithmetic::BigInteger& value) {
  *this = *this + value;
}
void big_num_arithmetic::BigInteger::operator+=(int64_t value) {
  if (sign_ == -1) {
    sign_ = 1;
    *this -= value;
    sign_ *= -1;
    return;
  }
  if (value < 0) {
    *this -= abs(value);
    return;
  }
  if (numbers_.empty()) {
    sign_ = 1;
    numbers_.push_back(value);
  } else {
    numbers_[0] += value;
  }
  this->FixOverflow();
}
void big_num_arithmetic::BigInteger::
operator-=(const big_num_arithmetic::BigInteger& value) {
  BigInteger answer = *this - value;
  *this = answer;
}
void big_num_arithmetic::BigInteger::operator-=(int64_t value) {
  if (sign_ == -1) {
    sign_ = 1;
    *this += value;
    sign_ *= -1;
    return;
  }
  if (value < 0) {
    *this += abs(value);
    return;
  }
  *this = *this - static_cast<BigInteger>(value);
}
void big_num_arithmetic::BigInteger::
operator*=(const big_num_arithmetic::BigInteger& value) {
  *this = *this * value;
}
void big_num_arithmetic::BigInteger::operator*=(int64_t value) {
  *this = *this * static_cast<BigInteger>(value);
}
void big_num_arithmetic::BigInteger::
operator/=(const big_num_arithmetic::BigInteger& value) {
  *this = *this / value;
}
void big_num_arithmetic::BigInteger::operator/=(int64_t value) {
  *this = *this / static_cast<BigInteger>(value);
}
big_num_arithmetic::BigInteger& big_num_arithmetic::BigInteger::operator++() {
  *this += 1;
  return *this;
}
big_num_arithmetic::BigInteger& big_num_arithmetic::BigInteger::operator--() {
  *this -= 1;
  return *this;
}
const big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator++(int) {
  BigInteger answer = *this;
  *this += 1;
  return answer;
}
const big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
operator--(int) {
  BigInteger answer = *this;
  *this -= 1;
  return answer;
}

big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
ToAnotherBase(int new_base) const {
  BigInteger answer;
  if (base_ == new_base) {
    answer = *this;
    return answer;
  }
  answer.base_ = new_base;
  answer.sign_ = this->sign_;
  for (int i = this->numbers_.size() - 1; i >= 0; --i) {
    for (int j = 0; j < answer.Size(); ++j) {
      answer.numbers_[j] *= this->base_;
    }
    if (answer.Size() > 0) {
      answer.numbers_[0] += this->numbers_[i];
    } else {
      answer.numbers_.push_back(this->numbers_[i]);
    }
    answer.FixOverflow();
  }
  return answer;
}
void big_num_arithmetic::BigInteger::
SplitValue(big_num_arithmetic::BigInteger& first_answer_value,
           big_num_arithmetic::BigInteger& second_answer_value,
           int second_size) const {
  second_answer_value.sign_ = 1;
  second_answer_value.base_ = this->base_;
  assert(second_size >= 0);
  second_answer_value.numbers_.resize(std::min(this->Size(), second_size));
  for (int i = 0; i < second_answer_value.Size(); ++i) {
    second_answer_value.numbers_[i] = this->numbers_[i];
  }
  second_answer_value.FixOverflow();
  first_answer_value.base_ = this->base_;
  if (this->Size() <= second_size) {
    first_answer_value.sign_ = 0;
    first_answer_value.numbers_.resize(0);
    return;
  }
  first_answer_value.sign_ = 1;
  first_answer_value.numbers_.resize(this->Size() - second_size);
  for (int i = second_size, j = 0; i < this->Size(); ++i, ++j) {
    first_answer_value.numbers_[j] = this->numbers_[i];
  }
  first_answer_value.FixOverflow();
}
void big_num_arithmetic::BigInteger::FixOverflow() {
  assert(base_ > 0);
  for (int i = 0; i < numbers_.size(); ++i) {
    if (numbers_[i] >= base_) {
      if (numbers_[i] >= base_ * 2) {
        if (i + 1 == numbers_.size()) {
          numbers_.push_back(numbers_[i] / base_);
        } else {
          numbers_[i + 1] += numbers_[i] / base_;
        }
        numbers_[i] %= base_;
      } else {
        if (i + 1 == numbers_.size()) {
          numbers_.push_back(1);
        } else {
          ++numbers_[i + 1];
        }
        numbers_[i] -= base_;
      }
    }
  }
  int new_size_of_array = Size();
  for (int i = Size() - 1; i >= 0; --i) {
    if (numbers_[i] == 0) {
      --new_size_of_array;
    } else {
      break;
    }
  }
  numbers_.resize(new_size_of_array);
  if (new_size_of_array == 0) {
    sign_ = 0;
  }
}
big_num_arithmetic::BigInteger big_num_arithmetic::BigInteger::
Karatsuba(const big_num_arithmetic::BigInteger& value) const {
  if (sign_ == 0 || value.sign_ == 0) {
    return BigInteger();
  }
  BigInteger answer;
  if (this->Size() == 1) {
    answer = value;
    answer.Abs();
    for (int i = 0; i < answer.Size(); ++i) {
      answer.numbers_[i] *= numbers_[0];
    }
    answer.FixOverflow();
    return answer;
  }
  if (value.Size() == 1) {
    answer = *this;
    answer.Abs();
    for (int i = 0; i < answer.Size(); ++i) {
      answer.numbers_[i] *= value.numbers_[0];
    }
    answer.FixOverflow();
    return answer;
  }

  BigInteger first_half_of_first_value, second_half_of_first_value,
      first_half_of_second_value, second_half_of_second_value,
      first_buffer_value, second_buffer_value;
  int size_of_second_half = (std::max(this->Size(), value.Size())) >> 1;
  this->SplitValue(first_half_of_first_value,
                   second_half_of_first_value,
                   size_of_second_half);
  value.SplitValue(first_half_of_second_value,
                   second_half_of_second_value,
                   size_of_second_half);
  first_buffer_value =
      first_half_of_first_value * first_half_of_second_value;
  second_buffer_value =
      second_half_of_first_value * second_half_of_second_value;
  answer = (((first_buffer_value << size_of_second_half)
      + (first_half_of_first_value + second_half_of_first_value)
          * (first_half_of_second_value + second_half_of_second_value)
      - first_buffer_value
      - second_buffer_value) << size_of_second_half)
      + second_buffer_value;
  return answer;
}
int big_num_arithmetic::BigInteger::SizeInBits(int64_t value) {
  int answer = 0;
  value = std::abs(value);
  while (value > 0) {
    value >>= 1;
    ++answer;
  }
  return answer;
}

std::ostream& big_num_arithmetic::
operator<<(std::ostream& stream,
           const big_num_arithmetic::BigInteger& value) {
  if (stream.flags() & std::ios_base::dec) {
    stream << value.ToString(10);
    return stream;
  }

  std::string answer_for_printing;
  int start_of_printing = 0;
  if (stream.flags() & std::ios_base::showbase) {
    if (value.Sign() == -1) {
      stream << "-";
      ++start_of_printing;
    }
    if (stream.flags() & std::ios_base::oct) {
      answer_for_printing = value.ToString(8);
      stream << "0";
    } else {
      answer_for_printing = value.ToString(16);
      stream << "0x";
    }
    for (int i = start_of_printing; i < answer_for_printing.size(); ++i) {
      stream << answer_for_printing[i];
    }
    return stream;
  }
  if (stream.flags() & std::ios_base::oct) {
    stream << value.ToString(8);
  } else {
    stream << value.ToString(16);
  }
  return stream;
}
std::istream& big_num_arithmetic::
operator>>(std::istream& stream,
           big_num_arithmetic::BigInteger& value) {
  std::string answer;
  stream >> answer;
  if (stream.flags() & std::ios_base::hex) {
    if (answer[0] == '-' && answer.size() > 2 && answer[2] == 'x') {
      answer[2] = '0';
    } else if (answer.size() > 1 && answer[1] == 'x') {
      answer[1] = '0';
    }
    value = BigInteger::FromString(answer, 16);
  } else if (stream.flags() & std::ios_base::oct) {
    value = BigInteger::FromString(answer, 8);
  } else {
    value = BigInteger::FromString(answer, 10);
  }
  return stream;
}
