#ifndef BIG_INTEGER_H_
#define BIG_INTEGER_H_
#include <iostream>
#include <vector>
#include <math.h>
#include <string>
#include <cassert>
#include <sstream>

namespace big_num_arithmetic {
class BigInteger {
 public:
  static int internal_base;
  BigInteger();
  explicit BigInteger(int64_t);
  explicit operator int64_t() const;
  int Sign() const;
  int Size() const;
  void Negate();
  void Abs();
  void Clear();
  static BigInteger FromString(const std::string&, int base);
  std::string ToString(int base) const;
  BigInteger& operator=(const BigInteger&) = default;

  bool operator==(const big_num_arithmetic::BigInteger&) const;
  bool operator!=(const big_num_arithmetic::BigInteger&) const;
  bool operator>(const big_num_arithmetic::BigInteger&) const;
  bool operator<(const big_num_arithmetic::BigInteger&) const;
  bool operator>=(const big_num_arithmetic::BigInteger&) const;
  bool operator<=(const big_num_arithmetic::BigInteger&) const;
  bool friend operator==(const BigInteger&, int64_t);
  bool friend operator==(int64_t, const BigInteger&);
  bool friend operator!=(const BigInteger&, int64_t);
  bool friend operator!=(int64_t, const BigInteger&);
  bool friend operator>(const BigInteger&, int64_t);
  bool friend operator>(int64_t, const BigInteger&);
  bool friend operator<(const BigInteger&, int64_t);
  bool friend operator<(int64_t, const BigInteger&);
  bool friend operator>=(const BigInteger&, int64_t);
  bool friend operator>=(int64_t, const BigInteger&);
  bool friend operator<=(const BigInteger&, int64_t);
  bool friend operator<=(int64_t, const BigInteger&);

  BigInteger operator+(const BigInteger&) const;
  friend BigInteger operator+(const BigInteger&, int64_t);
  friend BigInteger operator+(int64_t, const BigInteger&);
  BigInteger operator-(const BigInteger&) const;
  friend BigInteger operator-(const BigInteger&, int64_t);
  friend BigInteger operator-(int64_t, const BigInteger&);
  BigInteger operator*(const BigInteger&) const;
  friend BigInteger operator*(const BigInteger&, int64_t);
  friend BigInteger operator*(int64_t, const BigInteger&);
  BigInteger operator/(const BigInteger&) const;
  friend BigInteger
  operator/(int64_t first_value, const BigInteger& second_value) {
    return static_cast<big_num_arithmetic::BigInteger>(first_value)
        / second_value;
  }
  BigInteger operator/(int64_t) const;
  uint32_t operator%(uint32_t) const;
  BigInteger operator<<(int) const;
  // умнжение на систему счисления в степени value
  void operator<<=(int value);
  void operator+=(const BigInteger&);
  void operator+=(int64_t value);
  void operator-=(const BigInteger&);
  void operator-=(int64_t value);
  void operator*=(const BigInteger&);
  void operator*=(int64_t value);
  void operator/=(const BigInteger&);
  void operator/=(int64_t value);
  BigInteger& operator++();
  BigInteger& operator--();
  const BigInteger operator++(int);
  const BigInteger operator--(int);

 private:
  std::vector<int64_t> numbers_;
  int sign_;
  int base_;
  BigInteger ToAnotherBase(int) const;
  void SplitValue(BigInteger& first_answer_value,
                  BigInteger& second_answer_value,
                  int second_size) const;
  void FixOverflow();
  BigInteger Karatsuba(const BigInteger&) const;
  static int SizeInBits(int64_t value);
};
std::ostream& operator<<(std::ostream&,
                         const big_num_arithmetic::BigInteger&);
std::istream& operator>>(std::istream&,
                         big_num_arithmetic::BigInteger&);
}  // namespace big_num_arithmetic
#endif  // BIG_INTEGER_H_
