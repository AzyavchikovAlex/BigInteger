#ifndef EQUATION_SOLVER_H_
#define EQUATION_SOLVER_H_
#include "big_integer.h"
#include "helpers.h"
namespace equation_solver {
struct QuadraticEquation {
  big_num_arithmetic::BigInteger a, b, c;
};
QuadraticEquation GenerateEquation(const big_num_arithmetic::BigInteger& a,
                                   const big_num_arithmetic::BigInteger& x1,
                                   const big_num_arithmetic::BigInteger& x2);
bool Solve(const QuadraticEquation& equation,
           big_num_arithmetic::BigInteger& x1,
           big_num_arithmetic::BigInteger& x2);

}  // namespace equation_solver
#endif  // EQUATION_SOLVER_H_
